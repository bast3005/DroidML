import { DroidML } from './libs/DroidML@1.2.2.js'

function onStart() {
  let variables = {
    birthDate: null,
    months: {
      "January": 0,
      "February": 1,
      "March": 2,
      "April": 3,
      "May": 4,
      "June": 5,
      "July": 6,
      "August": 7,
      "September": 8,
      "October": 9,
      "November": 10,
      "December": 11,
    }
  };

  const { layouts, elements } = DroidML(`
    <Layout name="lay" backcolor="#1a7078">
      <Text name="title" text="Your age in Seconds" size="30"/>
      <Text name="header" text="Select your birthday" size="20"/>
      <Spinner name="yearSpinner" text="2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024"/>
      <Spinner name="monthSpinner" text="January,February,March,April,May,June,July,August,September,October,November,December"/>
      <Spinner name="daySpinner" text="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31"/>
      <Button name="btn" text="Click me" ontouch="(()=>{
        // Get values from spinners
        const year = allElements['yearSpinner'].GetText();
        const monthText = allElements['monthSpinner'].GetText();
        const month = variables.months[monthText]; // Get numeric month value from months map
        const day = allElements['daySpinner'].GetText();
        // Use the correct numeric values for year, month, and day
        variables.birthDate = new Date(year, month, day); // Correctly pass month as a number
        // Set interval to update age
        setInterval(() => {
          if (variables.birthDate) {
            let currentDate = new Date();
            let ageInMilliseconds = currentDate - variables.birthDate;
            
            let ageInSeconds = Math.floor(ageInMilliseconds / 1000);
            allElements['ageText'].SetText('You are ' + ageInSeconds + ' seconds old!');
          }
        }, 1); // Update every second
      })()"/>
      <Text name="ageText" text="" size="17"/>
    </Layout>
  `, variables);

  // Use elements returned from DroidML
  app.AddLayout(layouts["lay"]);
}